import tkinter as tk
from tkinter import ttk
import random
from Solve import *

class CrossLineGame:
    def __init__(self, root):
        self.root = root
        self.root.title("交叉线游戏智能求解器")
        self.root.geometry("1200x800")
        self.root.minsize(1000, 700)
        
        # 手动放置模式相关变量
        self.colors = ["#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEEAD", "#9B59B6", "#F39C12", "#27AE60", "#3498DB", "#E74C3C"]
        self.manual_mode = False
        self.temp_point = None
        self.current_pairs = 0
        self.manual_points = []
        self.points = []
        
        self.setup_styles()
        self.create_widgets()
        self.default_points = [((1, 5), (6, 1)), ((3, 1), (7, 2)), ((1, 4), (4, 2)), ((0, 1), (3, 2)), ((4, 0), (1, 7))]

    def setup_styles(self):
        # 自定义现代风格
        self.style = ttk.Style()
        self.style.theme_use("clam")
        self.style.configure("TButton", padding=6, relief="flat", background="#4A90E2", foreground="white")
        self.style.map("TButton", background=[("active", "#357ABD")])
        self.style.configure("TFrame", background="#F0F0F0")
        self.style.configure("TLabel", background="#F0F0F0", font=("Helvetica", 10))

    def create_widgets(self):
        # 主容器使用现代浅色背景
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        # 左侧控制面板
        self.control_frame = ttk.Frame(self.main_frame, width=250)
        self.control_frame.pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=10)
        self.create_controls()

        # 右侧棋盘区域
        self.board_frame = ttk.Frame(self.main_frame)
        self.board_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        self.create_board()

        # 状态栏
        self.status_bar = ttk.Frame(self.root)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=5)
        self.status_label = ttk.Label(self.status_bar, text="就绪", foreground="#666666")
        self.status_label.pack()

    def create_controls(self):
        # 控制面板标题
        ttk.Label(self.control_frame, text="游戏设置", font=("Helvetica", 12, "bold")).pack(pady=10)

        # 棋盘尺寸输入
        size_frame = ttk.Frame(self.control_frame)
        size_frame.pack(fill=tk.X, pady=5)
        ttk.Label(size_frame, text="棋盘尺寸:").pack(side=tk.LEFT)
        self.size_var = tk.IntVar(value=8)
        self.size_var.trace_add("write", lambda name, index, mode: self.validate_range(self.size_var,4,12,8))
        ttk.Spinbox(size_frame, from_=4, to=12, textvariable=self.size_var, width=5).pack(side=tk.RIGHT)
        
        # 点数输入
        points_frame = ttk.Frame(self.control_frame)
        points_frame.pack(fill=tk.X, pady=5)
        ttk.Label(points_frame, text="点对数:").pack(side=tk.LEFT)
        self.pairs_var = tk.IntVar(value=3)
        self.pairs_var.trace_add("write", lambda name, index, mode: self.validate_range(self.pairs_var,1,10,3))
        ttk.Spinbox(points_frame, from_=1, to=10, textvariable=self.pairs_var, width=5).pack(side=tk.RIGHT)

        # 生成按钮
        ttk.Button(self.control_frame, text="生成新棋盘", command=self.generate_board).pack(pady=15, ipadx=20)

        # 分隔线
        ttk.Separator(self.control_frame).pack(fill=tk.X, pady=10)
        
        # 添加生成模式选择
        ttk.Label(self.control_frame, text="生成模式:").pack(anchor=tk.W)
        self.mode_var = tk.StringVar(value="随机生成")
        ttk.Radiobutton(self.control_frame, text="随机生成", variable=self.mode_var, value="随机生成", 
                        command=self.update_mode).pack(anchor=tk.W)
        ttk.Radiobutton(self.control_frame, text="手动放置", variable=self.mode_var, value="手动放置",
                        command=self.update_mode).pack(anchor=tk.W)
        
        # 分隔线
        ttk.Separator(self.control_frame).pack(fill=tk.X, pady=10)

        # 算法选择
        ttk.Label(self.control_frame, text="路径算法:").pack(anchor=tk.W)
        self.algorithm_var = tk.StringVar(value="shortest")
        ttk.Radiobutton(self.control_frame, text="最短路径", variable=self.algorithm_var, value='shortest').pack(anchor=tk.W)
        ttk.Radiobutton(self.control_frame, text="综合代价", variable=self.algorithm_var, value='comprehensive').pack(anchor=tk.W)

        # 操作按钮
        btn_frame = ttk.Frame(self.control_frame)
        btn_frame.pack(pady=15)
        ttk.Button(btn_frame, text="开始求解", command=self.start_solve).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="重置", command=self.reset).pack(side=tk.RIGHT, padx=5)

    def validate_range(self, var, Low, Up, Default):
        """验证并限制棋盘尺寸在有效范围内"""
        try:
            value = var.get()
            if value < Low:
                var.set(Low)
            elif value > Up:
                var.set(Up)
        except:
            var.set(Default)  # 如果输入的不是数字，则恢复默认值

    def create_board(self):
        # 高分辨率画布
        self.canvas = tk.Canvas(self.board_frame, bg="white", bd=0, highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.draw_grid()

    def draw_grid(self):
        self.canvas.delete("grid")
        size = self.size_var.get()
        cell_size = 50  # 提高分辨率
        for i in range(size + 1):
            x = i * cell_size + 20  # 增加边距
            y = i * cell_size + 20
            self.canvas.create_line(20, y, size*cell_size+20, y, fill="#E0E0E0", tags="grid")
            self.canvas.create_line(x, 20, x, size*cell_size+20, fill="#E0E0E0", tags="grid")

    def generate_board(self):
        if self.manual_mode:
            self.status_label.config(text="手动模式下，请直接点击棋盘放置点对")
            return
            
        self.canvas.delete("all")
        self.draw_grid()
        size = self.size_var.get()
        pairs = self.pairs_var.get()

        # 生成随机点对
        
        self.points = []
        for i in range(pairs):
            color = self.colors[i % len(self.colors)]
            while True:
                x1, y1 = random.randint(0, size-1), random.randint(0, size-1)
                x2, y2 = random.randint(0, size-1), random.randint(0, size-1)
                if (x1, y1) != (x2, y2) and not self.point_exists(x1, y1) and not self.point_exists(x2, y2):
                    break
            # x1, y1 = self.default_points[i][0]
            # x2, y2 = self.default_points[i][1]
            self.draw_point(x1, y1, color)
            self.draw_point(x2, y2, color)
            self.points.append(((x1, y1), (x2, y2), color))

        self.status_label.config(text=f"已生成 {pairs} 对棋子")

    def draw_point(self, x, y, color):
        cell_size = 50
        # 绘制圆角小方块
        self.canvas.create_oval(
            x*cell_size + 30, y*cell_size + 30,
            (x+1)*cell_size + 10, (y+1)*cell_size + 10,
            fill=color, outline=color, width=2, tags="point",
        )

    def point_exists(self, x, y):
        for pair in self.points:
            if (x, y) in [pair[0], pair[1]]:
                return True
        return False
        
    def update_mode(self):
        """切换生成模式"""
        mode = self.mode_var.get()
        if mode == "手动放置":
            self.manual_mode = True
            self.canvas.bind("<Button-1>", self.handle_click)
            self.reset()  # 清空棋盘
            self.current_pairs = 0
            self.manual_points = []
            self.points = []
            self.status_label.config(text="手动模式：请点击棋盘放置点对（最多10对）")
        else:
            self.manual_mode = False
            self.canvas.unbind("<Button-1>")
            self.reset()
            self.points = []
            self.status_label.config(text="随机模式：请点击生成新棋盘按钮")

    def handle_click(self, event):
        """处理棋盘点击事件"""
        if self.current_pairs >= 10:
            self.status_label.config(text="已达到最大点对数量(10对)")
            return
        
        # 计算点击位置对应的棋盘坐标
        cell_size = 50
        x = (event.x - 20) // cell_size
        y = (event.y - 20) // cell_size
        size = self.size_var.get()
        
        # 确保点击在有效范围内
        if x < 0 or x >= size or y < 0 or y >= size:
            return
        
        # 检查该位置是否已经有点
        if self.point_exists(x, y):
            return
            
        colors = ["#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEEAD", "#9B59B6", "#F39C12", "#27AE60", "#3498DB", "#E74C3C"]
        
        if self.temp_point is None:
            # 第一次点击，记录临时点
            self.temp_point = (x, y)
            color = colors[self.current_pairs % len(colors)]
            self.draw_point(x, y, color)
            self.status_label.config(text=f"已选择第一个点 ({x},{y})，请选择第二个点")
        else:
            # 第二次点击，形成点对
            color = colors[self.current_pairs % len(colors)]
            self.draw_point(x, y, color)
            
            # 添加到点对列表
            self.points.append(((self.temp_point[0], self.temp_point[1]), (x, y), color))
            self.current_pairs += 1
            
            self.status_label.config(text=f"已添加点对 {self.current_pairs}/10")
            self.temp_point = None
            
            # 如果到达10对，更新状态
            if self.current_pairs >= 10:
                self.status_label.config(text="已达到最大点对数量(10对)，请点击求解")

    def start_solve(self):
        # 检查是否有点对可求解
        if not self.points:
            self.status_label.config(text="没有点对可供求解，请先生成或放置点对")
            return
            
        # 这里可以添加路径搜索算法
        self.status_label.config(text=f"正在计算{'最短' if self.algorithm_var.get() == 'shortest' else '综合最优'}路径...")
        Solver = CrossLineSolver(size=self.size_var.get(), points=self.points)
        info, success, result = Solver.solve(algorithm=self.algorithm_var.get())
        
        if success:
        # 首先清除之前的路径
            self.draw_path(result)
            self.status_label.config(text=f"已搜索{info[0]}s, {info[1]}个状态, {'最短' if self.algorithm_var.get() == 'shortest' else '综合最优'}路径计算完成，总代价{info[2]}！")
        else:
            self.status_label.config(text=f"已搜索{info[0]}s, {info[1]}个状态, 无法找到可行的路径，请重新放置点对")

    def draw_path(self, info):
        self.canvas.delete("path")  
        # 绘制成功的路径
        for path, color in info:
            # 逐段绘制路径中的每一步
            for i in range(len(path) - 1):
                p1 = path[i]      # 当前点
                p2 = path[i + 1]  # 下一个点
                
                # 转换为画布坐标
                x1 = p1[0] * 50 + 45  # 中心点坐标
                y1 = p1[1] * 50 + 45
                x2 = p2[0] * 50 + 45
                y2 = p2[1] * 50 + 45
                
                # 绘制连接线
                self.canvas.create_line(
                    x1, y1, x2, y2,
                    fill=color, width=3,
                    smooth=True, tags="path"
                )
    
    def reset(self):
        self.canvas.delete("all")
        self.draw_grid()
        if self.manual_mode:
            self.temp_point = None
            self.current_pairs = 0
            self.points = []
            self.status_label.config(text="已重置棋盘，请手动放置点对")
        else:
            self.points = []
            self.status_label.config(text="已重置棋盘")

if __name__ == "__main__":
    root = tk.Tk()
    app = CrossLineGame(root)
    root.mainloop()