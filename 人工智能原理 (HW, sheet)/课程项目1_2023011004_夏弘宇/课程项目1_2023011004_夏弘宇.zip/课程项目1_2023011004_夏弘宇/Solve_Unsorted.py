import time
import numpy as np
import heapq
from collections import deque

class GameState:
    """表示游戏的一个状态"""
    def __init__(self, grid_size, initial_grid=None):
        self.grid_size = grid_size
        # 如果提供了初始网格则复制，否则创建空网格
        if initial_grid is not None:
            self.grid = initial_grid.copy()
        else:
            self.grid = np.zeros((grid_size, grid_size), dtype=bool)
        
        self.paths = []  # 当前选择的路径列表，格式为 [(path, color), ...]
        self.total_cost = 0  # 当前总代价
        
    def is_occupied(self, pos):
        """检查位置是否被占用"""
        x, y = pos
        if x < 0 or x >= self.grid_size or y < 0 or y >= self.grid_size:
            return True  # 超出边界视为已占用
        return self.grid[x, y]
    
    def try_add_path(self, path, color, cost):
        """
        尝试添加一条路径
        如果路径与现有路径冲突，返回False
        否则添加路径并返回True
        """
        # 检查路径是否冲突（不包括起点和终点）
        for x, y in path[1:-1]:
            if self.grid[x, y]:
                return False
        
        # 路径不冲突，添加到状态
        self.paths.append((path, color))
        self.total_cost += cost
        
        # 更新网格占用情况
        for x, y in path[1:-1]:  # 不包括起点和终点
            self.grid[x, y] = True
            
        return True
    
    def copy(self):
        """创建状态的深拷贝"""
        new_state = GameState(self.grid_size, self.grid)
        new_state.paths = self.paths.copy()
        new_state.total_cost = self.total_cost
        return new_state


class CrossLineSolver:
    def __init__(self, size, points):
        self.grid_size = size
        self.points = points
        self.search_nodes = 0  # 搜索节点数
        self.path_cache = {}   # 缓存已生成的路径
        self.min_cost = {}
        for start, end, color in points:
            self.min_cost[(start, end)] = -1
        # 初始化网格，标记点的位置
        self.min_total_cost = 0
        self.max_lose_time = 0
        self.initial_grid = np.zeros((self.grid_size, self.grid_size), dtype=bool)
        for start, end, _ in points:
            self.initial_grid[start] = True
            self.initial_grid[end] = True

    def solve(self, algorithm="shortest"):
        """
        解决交叉线游戏
        algorithm: 算法类型，"shortest"或"comprehensive"
        """
        # 参数验证
        if algorithm not in ["shortest", "comprehensive"]:
            return (0, 0, 0), False, "算法类型错误"
        
        # 开始计时
        start_time = time.time()
        
        self.max_lose_time = 2 if algorithm == "shortest" else 8
        # 创建初始状态
        initial_state = GameState(self.grid_size, self.initial_grid)
        
        # 先生成所有点对的最短路径
        min_length_paths = {}
        for i, (start, end, color) in enumerate(self.points):
            paths = self.generate_paths(start, end, algorithm)
            if paths:
                self.path_cache[(start, end, 0)] = paths
            else:
                end_time = time.time()
                return (end_time - start_time, self.search_nodes), False, f"无法连接点对 {start} 和 {end}"
        self.min_total_cost = sum(self.min_cost.values())
        # 逐步增加允许的路径长度上限，直到找到解或确认无解
        max_extra_length = 0
        lose_time = 0
        while True:
            print(f"尝试使用额外长度上限: {max_extra_length}")
            
            # 为每对点生成可能的路径，限制在当前的长度上限内
            all_paths_for_pairs = []
            Flag = False  # 重置标记
            for start, end, color in self.points:
                key = (start, end, max_extra_length)
                key_0 = (start, end, max_extra_length-1)
                
                if key in self.path_cache:
                    paths = self.path_cache[key]
                else:
                    paths = self.generate_paths(start, end, algorithm, max_extra_length)
                    if key_0 in self.path_cache and len(paths) != len(self.path_cache[key_0]):
                        Flag = True
                    self.path_cache[key] = paths
                                
                all_paths_for_pairs.append((paths, color))
            
            if Flag == False and max_extra_length > 0:
                lose_time += 1
                max_extra_length += 1
                continue
            else:
                lose_time = 0
            
            if lose_time >= self.max_lose_time:
                break
            
                # 搜索最佳路径组合
            best_state = self.search_paths(initial_state, all_paths_for_pairs, algorithm)
            
            if best_state and best_state.total_cost <= max_extra_length + self.min_total_cost:
                end_time = time.time()
                return (end_time - start_time, self.search_nodes, best_state.total_cost), True, best_state.paths

            # 增加长度上限
            max_extra_length += 1

        end_time = time.time()
        return (end_time - start_time, self.search_nodes), False, "无法完成所有连接，请调整点的位置或尝试其他算法"
    
    def generate_paths(self, start, end, algorithm, max_extra_length=0):
        """
        使用优先队列（A*算法）生成从start到end的多条可能路径，限制额外长度
        返回按代价排序的路径列表 [(path, cost), ...]
        """
        paths = []
        
        # 优先队列实现，项为：(估计总代价, 实际代价, 路径ID, 当前位置, 路径)
        # 路径ID用于在估计总代价相同时的稳定排序
        path_id = 0
        queue = [(abs(start[0]-end[0]) + abs(start[1]-end[1]), 1, path_id, start, [start])]
        
        # 方向：上、右、下、左
        directions = [(0, -1), (1, 0), (0, 1), (-1, 0)]

        found_paths = 0
        while queue:
            # 取出估计代价最小的路径
            f_cost, current_cost, _, current, path = heapq.heappop(queue)
            
            # 如果当前路径长度已经超出限制，跳过
            if self.min_cost.get((start, end), 0) != -1 and \
            f_cost > self.min_cost[(start, end)] + max_extra_length:
                continue
                
            # 如果到达终点，记录路径
            if current == end:
                cost = self.calculate_cost(path, algorithm)
                paths.append((path, cost))
                found_paths += 1
                if self.min_cost.get((start, end), 0) == -1:
                    self.min_cost[(start, end)] = cost
                    
                continue
                                
            # 尝试四个方向
            for dx, dy in directions:
                nx, ny = current[0] + dx, current[1] + dy
                next_pos = (nx, ny)
                
                # 检查是否超出边界
                if nx < 0 or nx >= self.grid_size or ny < 0 or ny >= self.grid_size:
                    continue
                
                # 检查是否被占用(除了终点)
                if self.initial_grid[nx, ny] and next_pos != end:
                    continue
                
                flag = False
                for dx, dy in directions:
                    cx, cy = nx + dx, ny + dy
                    if (cx, cy) in path[:-1]:
                        flag = True
                        break
                if flag:
                    continue
                    
                # 计算到达新位置的代价
                if algorithm == "shortest":
                    new_cost = current_cost + 1  # 简单步数
                else:
                    # 检查是否形成转弯
                    if len(path) >= 2:
                        prev_dir = (current[0] - path[-2][0], current[1] - path[-2][1])
                        new_dir = (nx - current[0], ny - current[1])
                        turn_cost = 2 if prev_dir != new_dir else 0
                    else:
                        turn_cost = 0
                    new_cost = current_cost + 1 + turn_cost
                    
                # 如果找到了更好的路径，或者此位置还没有访问过
                    
                    # 计算估计总代价（实际代价 + 启发式估计）
                heuristic = abs(nx - end[0]) + abs(ny - end[1])  # 曼哈顿距离
                estimated_cost = new_cost + heuristic
                
                # 加入优先队列
                path_id += 1
                heapq.heappush(queue, (estimated_cost, new_cost, path_id, next_pos, path + [next_pos]))
        
        # 按代价排序
        paths.sort(key=lambda x: x[1])
        print(f'{start} -> {end} 找到 {found_paths} 条路径 (最大额外长度: {max_extra_length}).')
        return paths
    
    def search_paths(self, initial_state, all_paths, algorithm):
        """
        使用优先队列BFS搜索最佳路径组合
        initial_state: 初始游戏状态
        all_paths: 所有点对的候选路径
        algorithm: 算法类型
        """
        
        # 优先队列: (优先级, state_id, 当前状态, 已处理的点对索引)
        
        h_cost = []
        h_cost.append(0)
        for i in range(len(self.points)-1, -1, -1):
            st = self.points[i][0]
            ed = self.points[i][1]
            h_cost.append(h_cost[-1] + self.min_cost[(st, ed)])
        h_cost = h_cost[::-1]  # 反转为正序
        # 记录已访问状态，避免重复搜索
        # 使用当前网格状态的哈希值和已处理点对索引作为键
        visited = set()
        priority_queue = [(h_cost, 0, initial_state, 0)]
        # 用于生成唯一的state_id，防止优先级相同时比较状态对象
        state_id = 1
        
        while priority_queue:
            self.search_nodes += 1
            
            # 从优先队列中取出优先级最高的状态
            _, _, current_state, index = heapq.heappop(priority_queue)
            
            # 如果所有点对都已处理，找到了解
            if index >= len(all_paths):
                return current_state
            
            # 生成当前状态的哈希值，用于检查是否已访问
            grid_hash = hash(current_state.grid.tobytes())
            state_key = (grid_hash, index)
            
            # 如果状态已访问，跳过
            if state_key in visited:
                continue
                
            # 标记为已访问
            visited.add(state_key)
            
            # 获取当前点对的候选路径
            paths, color = all_paths[index]
            
            # 尝试每条候选路径
            for path, cost in paths:
                # 快速检查路径是否可行（避免不必要的状态复制）
                if any(current_state.is_occupied(pos) for pos in path[1:-1]):
                    continue
                    
                # 创建新状态
                new_state = current_state.copy()
                
                # 尝试添加路径
                if new_state.try_add_path(path, color, cost):
                    # 计算新状态的优先级
                    f_cost = new_state.total_cost + h_cost[index + 1]
                    
                    # 添加到优先队列
                    heapq.heappush(
                        priority_queue, 
                        (f_cost, state_id, new_state, index + 1)
                    )
                    state_id += 1
        
        # 如果队列为空但没找到解，则无解
        return None
    
    def calculate_cost(self, path, algorithm):
        """计算路径的综合代价（包括长度和转弯次数）"""
        
        if len(path) <= 2 or algorithm == "shortest":
            return len(path)
        
        cost = len(path) # 基础长度代价
        
        # 计算转弯次数
        turns = 0
        for i in range(1, len(path)-1):
            prev_dir = (path[i][0] - path[i-1][0], path[i][1] - path[i-1][1])
            next_dir = (path[i+1][0] - path[i][0], path[i+1][1] - path[i][1])
            if prev_dir != next_dir:
                turns += 1
        
        # 转弯代价
        cost += 2 * turns
        
        return cost