import os
import torch
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
import cv2
from PIL import Image
import yaml
from torchvision import transforms
from dataload import GarbageDataLoader
from model.light_cnn import LightCNN
from model.light_cnn_pro import LightCNNPro
from model.resnet import ResNetLightCNN
from model.attention_cnn import LightCNNWithAttention
plt.rcParams['font.family'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False
class ModelVisualizer:
    def __init__(self, model, dataloader, device, class_names, save_dir='visualization_results'):
        """
        初始化模型可视化器
        
        参数:
            model: 训练好的模型
            dataloader: 数据加载器
            device: 计算设备 (CPU/GPU)
            class_names: 类别名称列表
            save_dir: 保存可视化结果的目录
        """
        self.model = model
        self.dataloader = dataloader
        self.full_dataset = dataloader.full_dataset
        self.device = device
        self.class_names = class_names
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)
        self.model.eval()
        self.target_layer = self._find_target_layer()
        self.feature_maps = None
        self.gradients = None
        self._register_hooks()
    
    def _find_target_layer(self):
        """找到模型中最后一个卷积层"""
        if hasattr(self.model, 'features'):
            model_features = self.model.features
            target_layer = None
            for name, module in reversed(list(model_features.named_children())):
                if isinstance(module, torch.nn.Conv2d):
                    target_layer = module
                    break
            if target_layer is None:
                target_layer = list(model_features.children())[-1]
            return target_layer
        elif hasattr(self.model, 'layer4'):
            return self.model.layer4[-1].conv2
        elif hasattr(self.model, 'attention'):
            return self.model.attention
        else:
            last_conv = None
            for module in self.model.modules():
                if isinstance(module, torch.nn.Conv2d):
                    last_conv = module
            return last_conv
    
    def _register_hooks(self):
        """注册前向和后向钩子"""
        def forward_hook_fn(module, input, output):
            self.feature_maps = output
        def backward_hook_fn(module, grad_input, grad_output):
            self.gradients = grad_output[0]
        self.forward_hook = self.target_layer.register_forward_hook(forward_hook_fn)
        self.backward_hook = self.target_layer.register_full_backward_hook(backward_hook_fn)
    
    def generate_gradcam(self, input_image, target_class=None):
        """
        生成Grad-CAM热力图
        
        参数:
            input_image: 模型输入图像
            target_class: 目标类别索引，如果为None则使用预测的类别
            
        返回:
            heatmap: Grad-CAM热力图
            pred_class: 预测的类别
            pred_prob: 预测概率
        """
        
        if len(input_image.shape) == 3:
            input_image = input_image.unsqueeze(0)
        input_image = input_image.to(self.device)
        self.model.zero_grad()
        output = self.model(input_image)
        pred_probs = F.softmax(output, dim=1)
        pred_class = torch.argmax(pred_probs, dim=1).item()
        pred_prob = pred_probs[0, pred_class].item()
        if target_class is None:
            target_class = pred_class
        target = torch.zeros_like(output)
        target[0, target_class] = 1
        output.backward(gradient=target)
        gradients = self.gradients.detach().cpu()
        feature_maps = self.feature_maps.detach().cpu()
        weights = torch.mean(gradients, dim=(2, 3)).unsqueeze(2).unsqueeze(3)
        cam = torch.zeros(feature_maps.shape[2:]).numpy()
        for i, w in enumerate(weights[0]):
            cam += w.item() * feature_maps[0, i].numpy()
        cam = np.maximum(cam, 0)
        cam = cv2.resize(cam, (224, 224))
        cam = cam - np.min(cam)
        if np.max(cam) != 0:
            cam = cam / np.max(cam)
        return cam, pred_class, pred_prob
    
    def visualize_prediction(self, image_tensor, true_class=None, save_path=None, img_path=None):
        """
        可视化单张图像的预测和Grad-CAM
        
        参数:
            image_tensor: 输入图像张量
            true_class: 真实类别，如果有的话
            save_path: 保存路径，如果为None则显示而不保存
            img_path: 原始图像路径，如果提供则使用原始图像作为底图
        """
        input_tensor = image_tensor.clone()
        if img_path and os.path.exists(img_path):
            orig_image = Image.open(img_path).convert('RGB')
        else:
            denormalize = transforms.Compose([
                transforms.ToPILImage()
            ])
            orig_image = denormalize(image_tensor.cpu())
        heatmap, pred_class, pred_prob = self.generate_gradcam(input_tensor)
        heatmap_colored = cv2.applyColorMap(np.uint8(255 * heatmap), cv2.COLORMAP_JET)
        heatmap_colored = cv2.cvtColor(heatmap_colored, cv2.COLOR_BGR2RGB)
        heatmap_colored = cv2.resize(heatmap_colored, (orig_image.width, orig_image.height))
        np_img = np.array(orig_image)
        superimposed_img = cv2.addWeighted(np_img, 0.6, heatmap_colored, 0.4, 0)
        fig, axs = plt.subplots(1, 3, figsize=(15, 5))
        axs[0].imshow(orig_image)
        axs[0].set_title("原始图像")
        axs[0].axis('off')
        axs[1].imshow(cv2.resize(heatmap, (orig_image.width, orig_image.height)), cmap='jet')
        axs[1].set_title("Grad-CAM热力图")
        axs[1].axis('off')
        axs[2].imshow(superimposed_img)
        pred_label = self.class_names[pred_class]
        title = f"预测: {pred_label} ({pred_prob:.2f})"
        if true_class is not None:
            true_label = self.class_names[true_class]
            title += f"\n真实: {true_label}"
            color = "green" if pred_class == true_class else "red"
            axs[2].set_title(title, color=color)
        else:
            axs[2].set_title(title)
        axs[2].axis('off')
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path)
            plt.close()
        else:
            plt.show()
        return pred_class, true_class, pred_prob
    
    def analyze_failure_cases(self, num_cases=5):
        """分析和可视化模型失败的案例"""
        test_loader = self.dataloader.get_dataloader('test')
        test_indices = self.dataloader.test_indices  
        failure_cases = []
        index_in_test = 0  
        with torch.no_grad():
            for images, labels in test_loader:
                images = images.to(self.device)
                outputs = self.model(images)
                probs = F.softmax(outputs, dim=1)
                _, preds = torch.max(outputs, 1)
                for i in range(len(images)):
                    if preds[i].item() != labels[i].item():
                        orig_idx = test_indices[index_in_test + i]
                        img_path = self.full_dataset.image_paths[orig_idx]
                        failure_cases.append({
                            'image': images[i].cpu(),
                            'true_label': labels[i].item(),
                            'pred_label': preds[i].item(),
                            'confidence': probs[i, preds[i]].item(),
                            'img_path': img_path  
                        })
                index_in_test += len(images)
                if len(failure_cases) >= num_cases:
                    break
        result_dir = os.path.join(self.save_dir, 'failure_cases')
        os.makedirs(result_dir, exist_ok=True)
        for i, case in enumerate(failure_cases[:num_cases]):
            image = case['image']
            true_label = case['true_label']
            img_path = case['img_path']
            save_path = os.path.join(result_dir, f'failure_case_{i}.png')
            self.visualize_prediction(image, true_label, save_path, img_path)
    
    def generate_class_activation_maps(self, num_samples=3):
        """为每个类别生成类激活图"""
        class_samples = {}
        test_loader = self.dataloader.get_dataloader('test')
        test_indices = self.dataloader.test_indices
        index_in_test = 0
        for images, labels in test_loader:
            for i, label in enumerate(labels):
                label_item = label.item()
                if label_item not in class_samples:
                    class_samples[label_item] = []
                if len(class_samples[label_item]) < num_samples:
                    orig_idx = test_indices[index_in_test + i]
                    img_path = self.full_dataset.image_paths[orig_idx]
                    class_samples[label_item].append({
                        'image': images[i],
                        'img_path': img_path
                    })
            index_in_test += len(images)
            if all(len(samples) >= num_samples for samples in class_samples.values()):
                break
        result_dir = os.path.join(self.save_dir, 'class_activation_maps')
        os.makedirs(result_dir, exist_ok=True)
        for class_idx, samples in class_samples.items():
            class_name = self.class_names[class_idx]
            for i, sample in enumerate(samples[:num_samples]):
                save_path = os.path.join(result_dir, f'{class_name}_sample_{i}.png')
                self.visualize_prediction(sample['image'], class_idx, save_path, sample['img_path'])

    def cleanup(self):
        """清理注册的钩子"""
        self.forward_hook.remove()
        self.backward_hook.remove()

def load_config(config_path):
    """加载配置文件"""
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    return config

def main():
    config_path = 'configs/config.yml'
    config = load_config(config_path)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}")
    data_loader = GarbageDataLoader(
        root_dir=config['data']['root_dir'],
        batch_size=config['data']['batch_size'],
        num_workers=config['data']['num_workers'],
        val_size=config['data']['val_size'],
        test_size=config['data']['test_size'],
        random_seed=config['data']['random_seed']
    )
    num_classes = len(data_loader.full_dataset.categories)
    class_names = data_loader.full_dataset.categories
    if config['model']['name'] == 'LightCNN':
        model = LightCNN(num_classes=num_classes)
    elif config['model']['name'] == 'LightCNNPro':
        model = LightCNNPro(num_classes=num_classes)
    elif config['model']['name'] == 'ResNetLightCNN':
        model = ResNetLightCNN(num_classes=num_classes)
    elif config['model']['name'] == 'LightCNNWithAttention':
        model = LightCNNWithAttention(num_classes=num_classes)
    else:
        raise ValueError(f"不支持的模型类型: {config['model']['name']}")  
    model.load_state_dict(torch.load(config['model']['save_path']))
    model = model.to(device)
    visualizer = ModelVisualizer(
        model=model,
        dataloader=data_loader,
        device=device,
        class_names=class_names,
        save_dir='visualization_results'
    )
    print("开始生成可视化结果...")
    visualizer.analyze_failure_cases(num_cases=10)
    visualizer.generate_class_activation_maps(num_samples=3)
    visualizer.cleanup()
    print(f"可视化结果已保存到: {visualizer.save_dir}")

if __name__ == "__main__":
    main()