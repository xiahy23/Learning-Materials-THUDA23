import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
import time
import copy
import matplotlib.pyplot as plt
import yaml
from dataload import GarbageDataLoader
from model.light_cnn import LightCNN
from model.light_cnn_pro import LightCNNPro
from model.resnet import ResNetLightCNN
from model.attention_cnn import LightCNNWithAttention
plt.rcParams['font.family'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False

def train_model(model, dataloaders, criterion, optimizer, scheduler, device, history_path, num_epochs=25):
    since = time.time()
    best_model_wts = copy.deepcopy(model.state_dict())
    best_acc = 0.0
    history = {
        'train_loss': [],
        'train_acc': [],
        'val_loss': [],
        'val_acc': []
    }
    for epoch in range(num_epochs):
        print(f'Epoch {epoch+1}/{num_epochs}')
        print('-' * 10)
        for phase in ['train', 'valid']:
            if phase == 'train':
                model.train()
            else:
                model.eval()
            running_loss = 0.0
            running_corrects = 0
            cnt = 0
            for inputs, labels in dataloaders.get_dataloader(phase):
                inputs = inputs.to(device)
                labels = labels.to(device)
                cnt += labels.size(0)
                with torch.set_grad_enabled(phase == 'train'):
                    outputs = model(inputs)
                    _, preds = torch.max(outputs, 1)
                    loss = criterion(outputs, labels)
                    if phase == 'train':
                        optimizer.zero_grad()
                        loss.backward()
                        optimizer.step()
                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels.data)
            
            if phase == 'train' and scheduler is not None:
                scheduler.step()
            epoch_loss = running_loss / cnt
            epoch_acc = running_corrects.double() / cnt
            if phase == 'train':
                history['train_loss'].append(epoch_loss)
                history['train_acc'].append(epoch_acc.item())
            else:
                history['val_loss'].append(epoch_loss)
                history['val_acc'].append(epoch_acc.item())
            print(f'{phase} Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}')
            if phase == 'valid' and epoch_acc > best_acc:
                best_acc = epoch_acc
                best_model_wts = copy.deepcopy(model.state_dict())
        print()
    time_elapsed = time.time() - since
    print(f'Training complete in {time_elapsed // 60:.0f}m {time_elapsed % 60:.0f}s')
    print(f'Best val Acc: {best_acc:.4f}')
    model.load_state_dict(best_model_wts)
    plot_training_history(history, history_path)
    return model, history

def plot_training_history(history, img_path):
    plt.figure(figsize=(12, 4))
    plt.subplot(1, 2, 1)
    plt.plot(history['train_loss'], label='Train')
    plt.plot(history['val_loss'], label='Validation')
    plt.title('Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.subplot(1, 2, 2)
    plt.plot(history['train_acc'], label='Train')
    plt.plot(history['val_acc'], label='Validation')
    plt.title('Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.tight_layout()
    plt.savefig(img_path)
    plt.close()

def load_config(config_path):
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    return config

def main():
    config_path = 'configs/config.yml'
    config = load_config(config_path)
    print("训练配置:")
    print(f"- 数据集路径: {config['data']['root_dir']}")
    print(f"- 批大小: {config['data']['batch_size']}")
    print(f"- 使用数据增强: {config['data']['augmentation']['use_augmentation']}")
    print(f"- 通过采样平衡类别: {config['data']['augmentation']['balance_classes']}")
    print(f"- 通过数据增强平衡类别: {config['data']['augmentation']['augment_balance']}")
    print(f"- 训练轮数: {config['training']['num_epochs']}")
    print(f"- 学习率: {config['training']['learning_rate']}")
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    data_loader = GarbageDataLoader(
        root_dir=config['data']['root_dir'],
        batch_size=config['data']['batch_size'],
        num_workers=config['data']['num_workers'],
        val_size=config['data']['val_size'],
        test_size=config['data']['test_size'],
        random_seed=config['data']['random_seed'],
        use_augmentation=config['data']['augmentation']['use_augmentation'],
        balance_classes=config['data']['augmentation']['balance_classes'],
        augment_balance=config['data']['augmentation']['augment_balance']
    )
    data_loader.print_dataset_info()
    num_classes = len(data_loader.full_dataset.categories)
    class_names = data_loader.full_dataset.categories
    print(f"Number of classes: {num_classes}")
    print(f"Class names: {class_names}")
    if config['model']['name'] == 'LightCNN':
        model = LightCNN(num_classes=num_classes)
    elif config['model']['name'] == 'LightCNNPro':
        model = LightCNNPro(num_classes=num_classes)
    elif config['model']['name'] == 'ResNetLightCNN':
        model = ResNetLightCNN(num_classes=num_classes)
    elif config['model']['name'] == 'LightCNNWithAttention':
        model = LightCNNWithAttention(num_classes=num_classes)
    else:
        raise ValueError(f"不支持的模型类型: {config['model']['name']}")  
    model = model.to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=config['training']['learning_rate'])
    scheduler = lr_scheduler.StepLR(
        optimizer, 
        step_size=config['training']['scheduler_step_size'], 
        gamma=config['training']['scheduler_gamma']
    )
    model, history = train_model(
        model=model,
        dataloaders=data_loader,
        criterion=criterion,
        optimizer=optimizer,
        scheduler=scheduler,
        device=device,
        history_path=config['res']['history_path'],
        num_epochs=config['training']['num_epochs']
    )
    torch.save(model.state_dict(), config['model']['save_path'])
    print("Training complete!")

if __name__ == "__main__":
    main()