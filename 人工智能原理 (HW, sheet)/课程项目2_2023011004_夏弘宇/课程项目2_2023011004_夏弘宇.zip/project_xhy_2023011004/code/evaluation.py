import torch
import numpy as np
from sklearn.metrics import confusion_matrix, classification_report
import matplotlib.pyplot as plt
import yaml  
import os
plt.rcParams['font.family'] = 'SimHei'  
plt.rcParams['axes.unicode_minus'] = False  
from dataload import GarbageDataLoader
from model.light_cnn import LightCNN
from model.light_cnn_pro import LightCNNPro
from model.resnet import ResNetLightCNN
from model.attention_cnn import LightCNNWithAttention
def evaluate_model(model, dataloader, device, class_names):
    model.eval()
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for inputs, labels in dataloader:
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    cm = confusion_matrix(all_labels, all_preds)
    report = classification_report(all_labels, all_preds, target_names=class_names, digits=3)
    plt.figure(figsize=(10, 8))
    plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title('Confusion Matrix')
    plt.colorbar()
    tick_marks = np.arange(len(class_names))
    plt.xticks(tick_marks, class_names, rotation=45)
    plt.yticks(tick_marks, class_names)
    thresh = cm.max() / 2.
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            plt.text(j, i, format(cm[i, j], 'd'),
                     horizontalalignment="center",
                     color="white" if cm[i, j] > thresh else "black")
    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.savefig('confusion_matrix04.png')
    plt.close()
    print(report)
    return cm, report
def load_config(config_path):
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    return config
def main():
    config_path = 'configs/config.yml'
    config = load_config(config_path)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    print("评估配置:")
    print(f"- 数据集路径: {config['data']['root_dir']}")
    print(f"- 批大小: {config['data']['batch_size']}")
    print(f"- 模型文件: {config['model']['save_path']}")
    data_loader = GarbageDataLoader(
        root_dir=config['data']['root_dir'],
        batch_size=config['data']['batch_size'],
        num_workers=config['data']['num_workers'],
        val_size=config['data']['val_size'],
        test_size=config['data']['test_size'],
        random_seed=config['data']['random_seed']
    )
    num_classes = len(data_loader.full_dataset.categories)
    class_names = data_loader.full_dataset.categories
    print(f"Number of classes: {num_classes}")
    print(f"Class names: {class_names}")
    if config['model']['name'] == 'LightCNN':
        model = LightCNN(num_classes=num_classes)
    elif config['model']['name'] == 'LightCNNPro':
        model = LightCNNPro(num_classes=num_classes)
    elif config['model']['name'] == 'ResNetLightCNN':
        model = ResNetLightCNN(num_classes=num_classes)
    elif config['model']['name'] == 'LightCNNWithAttention':
        model = LightCNNWithAttention(num_classes=num_classes)
    else:
        raise ValueError(f"不支持的模型类型: {config['model']['name']}")  
    model.load_state_dict(torch.load(config['model']['save_path']))
    model = model.to(device)
    test_loader = data_loader.get_dataloader('test')
    cm, report = evaluate_model(model, test_loader, device, class_names)
    print("Evaluation complete!")
if __name__ == "__main__":
    main()