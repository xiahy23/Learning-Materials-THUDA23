# ReadMe of 垃圾分类图像识别系统

**project_xhy_2023011004**

## 1. 项目概述
本项目实现了一个基于深度学习的垃圾分类识别系统，使用卷积神经网络对垃圾图像进行分类。系统支持多种模型架构，包括`LightCNN`、`LightCNNPro`、`ResNetLightCNN`和带注意力机制的`LightCNNWithAttention`模型。

**项目主要功能包括**：

- 垃圾图像数据的加载和预处理
- 模型训练与优化
- 模型评估与测试
- 可视化分析（包括Grad-CAM可视化、混淆矩阵等）

## 2. 环境配置

### 硬件依赖

- LightCNN：4G显存
- LightCNNpro：10G显存
- ResNetLightCNN：2G显存
- AttentionCNN：5G显存

### 依赖库
建议选择python=3.8，并使用`pip`安装以下依赖库，安装前，请根据自己的cuda版本选择合适的torch和torchvision版本，并仿照如下脚本安装：

```bash
cd code
pip install torch==2.1.0+cu121 torchvision==0.16.0+cu121 torchaudio==2.1.0+cu121 --index-url https://download.pytorch.org/whl/cu121
pip install -r requirements.txt
```

## 3. 数据准备

- 数据集下载：[下载链接](https://cloud.tsinghua.edu.cn/f/4a89782049fc4f1aa9ce/?dl=1)
- 放置位置：与dataload.py同级目录下
```bash
unzip Garbage-Classification.zip
```

## 4. 项目结构

```
./
├── dataload.py          # 数据加载和预处理
├── train.py             # 模型训练
├── evaluation.py        # 模型评估
├── visualize.py         # 模型可视化
├── configs/             # 配置文件
│   └── config.yml
├── model/               # 模型定义
│   ├── light_cnn.py     # 基础LightCNN
│   ├── light_cnn_pro.py # 改进的LightCNN
│   ├── resnet.py        # 基于ResNet的模型
│   └── attention_cnn.py # 带注意力机制的CNN
├── cache/               # 保存训练好的模型
│   └── *.pth
└── garbage-dataset/     # 数据集
    └── */               # 各类别图像
```

## 5. 配置文件说明

```yaml
# 数据相关配置
data:
  root_dir: './garbage-dataset' # 数据集相对dataload.py的路径
  batch_size: 32 # 批量大小
  num_workers: 4 # 多线程加载数据
  val_size: 0.15 # 验证集占比
  test_size: 0.15 # 测试集占比
  random_seed: 42 # 保持不变，则每次分割的数据集都一致，控制变量
  # 数据增强配置
  augmentation:
    use_augmentation: true  # 是否使用基本数据增强
    balance_classes: false  # 是否通过采样平衡类别——不建议和数据增强同时使用true，否则少数的数据会过采样，反而在占大比重的数据中表现不佳
    augment_balance: true   # 是否通过数据增强平衡类别

# 模型相关配置
model:
  name: 'LightCNN' # 模型名称，可在LightCNN/LightCNNPro/ResNetLightCNN/LightCNNWithAttention中选择
  save_path: 'cache/classifier1.pth' # 模型保存路径

# 训练相关配置
training:
  num_epochs: 25
  learning_rate: 0.001 # 初始学习率
  scheduler_step_size: 7 # 学习率衰减步长（每7个epoch衰减一次）
  scheduler_gamma: 0.1 # 学习率衰减（每7个epoch衰减0.1倍）

res:
  history_path: 'train_history1.png' # 训练历史记录保存路径
```

## 6. 使用方法
### 6.1 训练模型
```bash
python train.py
``` 
### 6.2 评估模型
```bash
python evaluation.py
```
### 6.3 可视化
```bash
python visualize.py
```
注：可视化会在```visualization_results```文件夹下生成```class_activation_maps```和```failure_cases```两个文件夹，分别是每类随机取三张图以及整体任取10个预测失败的例子的热力图供分析。