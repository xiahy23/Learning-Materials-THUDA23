import os
import torch
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from torch.utils.data import Dataset, DataLoader
from torch.utils.data.sampler import WeightedRandomSampler
from torchvision import transforms
from sklearn.model_selection import train_test_split
from collections import Counter
plt.rcParams['font.family'] = 'SimHei'  
plt.rcParams['axes.unicode_minus'] = False  
class GarbageDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        """
        初始化数据集
        参数:
            root_dir (str): 数据集根目录
            transform: 图像变换
        """
        self.root_dir = root_dir
        self.transform = transform
        self.categories = [d for d in os.listdir(root_dir) if os.path.isdir(os.path.join(root_dir, d))]
        self.categories.sort()
        self.class_to_idx = {cls: i for i, cls in enumerate(self.categories)}
        self.idx_to_class = {i: cls for i, cls in enumerate(self.categories)}
        self.image_paths = []
        self.labels = []
        for category in self.categories:
            category_path = os.path.join(self.root_dir, category)
            label = self.class_to_idx[category]
            images = [os.path.join(category_path, f) 
                      for f in os.listdir(category_path) 
                      if f.endswith(('.jpg', '.jpeg', '.png'))]
            self.image_paths.extend(images)
            self.labels.extend([label] * len(images))
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        label = self.labels[idx]
        image = Image.open(img_path).convert('RGB')
        if self.transform:
            image = self.transform(image)
        return image, label
    
    def get_class_distribution(self, indices=None):
        if indices is None:
            counter = Counter(self.labels)
        else:
            counter = Counter([self.labels[i] for i in indices])
        return {self.idx_to_class[idx]: count for idx, count in counter.items()}
    
    def visualize_samples(self, num_samples=5, indices=None):
        fig, axes = plt.subplots(1, num_samples, figsize=(15, 3))
        if indices is None:
            indices = np.random.choice(len(self), num_samples, replace=False)
        else:
            indices = np.random.choice(indices, min(num_samples, len(indices)), replace=False)
        for i, idx in enumerate(indices):
            image, label = self.__getitem__(idx)
            if isinstance(image, torch.Tensor):
                image = transforms.ToPILImage()(image)
            axes[i].imshow(image)
            axes[i].set_title(f"类别: {self.idx_to_class[label]}")
            axes[i].axis('off')
        plt.tight_layout()
        plt.show()
        plt.close()

class BalancedAugmentDataset(Dataset):
    def __init__(self, dataset, indices, transform=None, balance_classes=False):
        self.dataset = dataset
        self.indices = indices
        self.base_transform = transform
        self.balance_classes = balance_classes
        self.labels = [dataset.labels[i] for i in indices]
        class_counts = Counter(self.labels)
        self.idx_mapping = []
        self.internal_labels = []
        if balance_classes:
            max_samples = max(class_counts.values())
            for i, idx in enumerate(indices):
                label = dataset.labels[idx]
                count = class_counts[label]
                augment_times = int(np.ceil(max_samples / count))
                for j in range(augment_times):
                    self.idx_mapping.append((i, j))
                    self.internal_labels.append(label)
        else:
            self.idx_mapping = [(i, 0) for i in range(len(indices))]
            self.internal_labels = self.labels
        self.augment_transforms = self._create_augment_transforms()
    
    def _create_augment_transforms(self):
        base_aug = transforms.Compose([
            transforms.RandomResizedCrop(224, scale=(0.8, 1.0)),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])
        medium_aug = transforms.Compose([
            transforms.RandomResizedCrop(224, scale=(0.7, 1.0)),
            transforms.RandomHorizontalFlip(),
            transforms.RandomVerticalFlip(p=0.3),
            transforms.RandomRotation(20),
            transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.3),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])
        strong_aug = transforms.Compose([
            transforms.RandomResizedCrop(224, scale=(0.6, 1.0)),
            transforms.RandomHorizontalFlip(),
            transforms.RandomVerticalFlip(p=0.4),
            transforms.RandomRotation(30),
            transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.1),
            transforms.RandomAffine(degrees=0, translate=(0.1, 0.1), scale=(0.8, 1.2)),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])
        transforms_list = [self.base_transform, base_aug, medium_aug, strong_aug]
        return transforms_list
    
    def __len__(self):
        return len(self.idx_mapping)
    
    def __getitem__(self, idx):
        orig_idx, aug_level = self.idx_mapping[idx]
        image, label = self.dataset[self.indices[orig_idx]]
        if aug_level >= len(self.augment_transforms):
            transform_idx = np.random.randint(1, len(self.augment_transforms))
        else:
            transform_idx = aug_level
        transform = self.augment_transforms[transform_idx]
        if transform:
            image = transform(image)   
        return image, label

class GarbageDataLoader:
    def __init__(self, root_dir, batch_size=32, num_workers=4, val_size=0.15, test_size=0.15, 
                random_seed=42, use_augmentation=False, balance_classes=False, augment_balance=False):
        """
        初始化数据加载器
        
        参数:
            root_dir (str): 数据集根目录
            batch_size (int): 批大小
            num_workers (int): 数据加载线程数
            val_size (float): 验证集比例
            test_size (float): 测试集比例
            random_seed (int): 随机种子
            use_augmentation (bool): 是否使用增强的数据预处理
            balance_classes (bool): 是否通过采样平衡各类别样本数量
            augment_balance (bool): 是否通过数据增强平衡各类别样本数量
        """
        self.root_dir = root_dir
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.val_size = val_size
        self.test_size = test_size
        self.random_seed = random_seed
        self.use_augmentation = use_augmentation
        self.balance_classes = balance_classes
        self.augment_balance = augment_balance
        self.basic_transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])
        self.full_dataset = GarbageDataset(root_dir=root_dir, transform=None)
        self.train_indices, self.val_indices, self.test_indices = self._split_indices()
        if self.augment_balance:
            self.train_dataset = BalancedAugmentDataset(
                dataset=self.full_dataset,
                indices=self.train_indices,
                transform=self.basic_transform,
                balance_classes=True
            )
        else:
            self.train_dataset = TransformedSubset(
                dataset=self.full_dataset,
                indices=self.train_indices,
                transform=self.basic_transform
            )
        
        self.val_dataset = TransformedSubset(
            dataset=self.full_dataset,
            indices=self.val_indices,
            transform=self.basic_transform
        )
        self.test_dataset = TransformedSubset(
            dataset=self.full_dataset,
            indices=self.test_indices,
            transform=self.basic_transform
        )
        if self.balance_classes:
            train_sampler = self._create_balanced_sampler(self.train_indices)
            self.train_loader = DataLoader(
                self.train_dataset, 
                batch_size=batch_size, 
                sampler=train_sampler,  
                num_workers=num_workers,
                pin_memory=True
            )
        else:
            self.train_loader = DataLoader(
                self.train_dataset, 
                batch_size=batch_size, 
                shuffle=True, 
                num_workers=num_workers,
                pin_memory=True
            )
        self.val_loader = DataLoader(
            self.val_dataset, 
            batch_size=batch_size, 
            shuffle=False, 
            num_workers=num_workers,
            pin_memory=True
        )
        self.test_loader = DataLoader(
            self.test_dataset, 
            batch_size=batch_size, 
            shuffle=False, 
            num_workers=num_workers,
            pin_memory=True
        )
    
    def _create_balanced_sampler(self, indices):
        labels = [self.full_dataset.labels[i] for i in indices]
        class_counts = Counter(labels)
        weights = [1.0 / class_counts[labels[i]] for i in range(len(labels))]
        sampler = WeightedRandomSampler(
            weights=weights,
            num_samples=len(indices),
            replacement=True
        )
        return sampler
    
    def _split_indices(self):
        all_indices = np.arange(len(self.full_dataset))
        train_indices, temp_indices = train_test_split(
            all_indices, 
            test_size=self.val_size+self.test_size, 
            random_state=self.random_seed, 
            stratify=self.full_dataset.labels
        )
        val_indices, test_indices = train_test_split(
            temp_indices, 
            test_size=self.test_size/(self.val_size+self.test_size), 
            random_state=self.random_seed, 
            stratify=[self.full_dataset.labels[i] for i in temp_indices]
        )
        return train_indices, val_indices, test_indices
    
    def get_dataloader(self, mode='train'):
        if mode == 'train':
            return self.train_loader
        elif mode == 'valid':
            return self.val_loader
        elif mode == 'test':
            return self.test_loader
        else:
            raise ValueError(f"不支持的模式: {mode}")
    
    def get_dataset_info(self):
        """获取数据集信息"""
        categories = self.full_dataset.categories
        train_dist = self.full_dataset.get_class_distribution(self.train_indices)
        val_dist = self.full_dataset.get_class_distribution(self.val_indices)
        test_dist = self.full_dataset.get_class_distribution(self.test_indices)
        info = {
            '类别数': len(categories),
            '类别': categories,
            '训练集大小': len(self.train_indices),
            '验证集大小': len(self.val_indices),
            '测试集大小': len(self.test_indices),
            '训练集分布': train_dist,
            '验证集分布': val_dist,
            '测试集分布': test_dist,
            '各类别样本数': []
        }
        if self.augment_balance:
            original_class_counts = Counter([self.full_dataset.labels[i] for i in self.train_indices])
            augmented_counts = Counter(self.train_dataset.internal_labels)
            augment_ratios = {}
            for label, orig_count in original_class_counts.items():
                aug_count = augmented_counts.get(label, 0)
                info['各类别样本数'].append(aug_count)
                class_name = self.full_dataset.idx_to_class[label]
                augment_ratios[class_name] = aug_count / orig_count
            
            info['增强后训练集大小'] = len(self.train_dataset)
            info['类别增强比例'] = augment_ratios
        return info
    
    def print_dataset_info(self):
        """打印数据集信息"""
        info = self.get_dataset_info()
        print(f"数据集信息:")
        print(f"总类别数: {info['类别数']}")
        print(f"类别: {info['类别']}")
        print(f"训练集大小: {info['训练集大小']}")
        print(f"验证集大小: {info['验证集大小']}")
        print(f"测试集大小: {info['测试集大小']}")
        if self.augment_balance:
            print(f"增强后训练集大小: {len(self.train_dataset)}")
            print(f"增强后训练集分布: {info['各类别样本数']}")
            print(f"增强比例: {len(self.train_dataset) / info['训练集大小']:.2f}倍")
        categories = info['类别']
        train_counts = [info['训练集分布'].get(cat, 0) for cat in categories]
        val_counts = [info['验证集分布'].get(cat, 0) for cat in categories]
        test_counts = [info['测试集分布'].get(cat, 0) for cat in categories]
        width = 0.25
        x = np.arange(len(categories))
        plt.figure(figsize=(15, 6))
        plt.bar(x - width, train_counts, width, label='训练集')
        plt.bar(x, val_counts, width, label='验证集')
        plt.bar(x + width, test_counts, width, label='测试集')
        plt.xlabel('类别')
        plt.ylabel('图像数量')
        plt.title('数据集类别分布')
        plt.xticks(x, categories, rotation=90)
        plt.legend()
        plt.tight_layout()
        plt.savefig('dataset_distribution.png')
        plt.show()
    
    def visualize_augmentations(self, num_samples=3):
        """展示数据增强效果"""
        if not self.augment_balance:
            print("未启用数据增强平衡，无法展示增强效果")
            return
        indices = []
        categories = self.full_dataset.categories
        for cat_idx, cat in enumerate(categories):
            cat_samples = [i for i, idx in enumerate(self.train_indices) 
                        if self.full_dataset.labels[idx] == cat_idx]
            if cat_samples:
                indices.append(np.random.choice(cat_samples))   
        
        while len(indices) < num_samples:
            idx = np.random.randint(0, len(self.train_indices))
            if idx not in indices:
                indices.append(idx)
        aug_transforms = self.train_dataset.augment_transforms
        for idx in indices[:num_samples]:
            img_idx = self.train_indices[idx]
            image, label = self.full_dataset[img_idx]
            class_name = self.full_dataset.idx_to_class[label]
            fig, axes = plt.subplots(1, len(aug_transforms), figsize=(15, 3))
            axes[0].imshow(image)
            axes[0].set_title(f"原图\n类别: {class_name}")
            axes[0].axis('off')
            for i in range(1, len(aug_transforms)):
                if aug_transforms[i]:
                    aug_img = aug_transforms[i](image)
                    if isinstance(aug_img, torch.Tensor):
                        aug_img = transforms.ToPILImage()(aug_img)
                    axes[i].imshow(aug_img)
                    axes[i].set_title(f"增强 {i}\n类别: {class_name}")
                    axes[i].axis('off')
            plt.tight_layout()
            plt.savefig(f'augmentation_example_{class_name}.png')
            plt.show()

class TransformedSubset(Dataset):
    def __init__(self, dataset, indices, transform=None):
        self.dataset = dataset
        self.indices = indices
        self.transform = transform
        
    def __len__(self):
        return len(self.indices)
    
    def __getitem__(self, idx):
        image, label = self.dataset[self.indices[idx]]
        if self.transform:
            image = self.transform(image)
        return image, label


if __name__ == "__main__":
    data_loader = GarbageDataLoader(
        root_dir="./garbage-dataset",
        batch_size=32,
        num_workers=4,
        use_augmentation=True,
        balance_classes=False,  
        augment_balance=True    
    )
    train_loader = data_loader.get_dataloader('train')
    val_loader = data_loader.get_dataloader('valid')
    test_loader = data_loader.get_dataloader('test')
    data_loader.print_dataset_info()
    data_loader.visualize_augmentations(num_samples=5)